﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace testpim
{
    public class Formulario
    {
        public void RetiraMascaras(MaskedTextBox maskedTextBox)
        {
            maskedTextBox.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;
        }

        public void LimpaTextBoxs(TextBox textbox)
        {
            textbox.Clear();
        }

        public void LimpaMaskedTextBoxs(MaskedTextBox maskedTextBox)
        {
            maskedTextBox.Clear();
        }

        

       

        public void IncluirMascaras(MaskedTextBox maskedTextBox)
        {
            maskedTextBox.TextMaskFormat = MaskFormat.IncludePromptAndLiterals;
        }

    }
}
