﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using testpim.Dao;

namespace testpim
{
    public partial class ListarProduto : Form
    {
       
        Produto prod;
        public ListarProduto()
        {
            InitializeComponent();
            prod = new Produto();
          
        }
        DataTable BuscarFornecedorPorId(Label id_fornec)
        {
            MySqlConnection Con = new ConnectionFactory().Connectar();
            Con.Open();
            string buscar_fornecedor = "Select nome_fantasia  from fornecedor where id_fornec = '" + id_fornec.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_fornecedor, Con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;
        }

        DataTable BuscarProdutosFornecedorId(Label id)
        {
            MySqlConnection Con = new ConnectionFactory().Connectar();
            Con.Open();
            string buscar_fornecedor = " Select id_produto,nome,descricao,marca,tipo,sub_tipo,genero,faixa_etaria,preco_venda,preco_custo,qtd_min,qtd_max,data_criacao,obs,id_fornecedor from demo where id_fornecedor='" + id.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_fornecedor, Con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;
        }

        DataTable BuscarProdutosFornecedorNome(TextBox nome)
        {
            MySqlConnection Con = new ConnectionFactory().Connectar();
            Con.Open();
            string buscar_fornecedor = " Select id_fornec from fornecedor where nome_fantasia='" + nome.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_fornecedor, Con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (produtoTbx.Text != "")
            {
                dataGridView1.DataSource = prod.BuscarProduto(produtoTbx);

               marcaTbx.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
              tipoCbx.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
               subtipoCbx.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
              generoCbx.Text= dataGridView1.CurrentRow.Cells[6].Value.ToString();
                faixaetariaCbx.Text= dataGridView1.CurrentRow.Cells[7].Value.ToString();
                datacriacaoMtbx.Text= dataGridView1.CurrentRow.Cells[12].Value.ToString();
                nomefornecedorLbl.Text = dataGridView1.CurrentRow.Cells[14].Value.ToString();
                nomefornecedorLbl.Visible = false;
              dataGridView1.DataSource=  BuscarFornecedorPorId(nomefornecedorLbl);
                nomefantTbx.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            }
            if (nomefantTbx.Text != "")
            {
                dataGridView1.DataSource = BuscarProdutosFornecedorNome(nomefantTbx);
                id_fornec.Text= dataGridView1.CurrentRow.Cells[0].Value.ToString();
                id_fornec.Visible = false;
                dataGridView1.DataSource = BuscarProdutosFornecedorId(id_fornec);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }
    }
}
