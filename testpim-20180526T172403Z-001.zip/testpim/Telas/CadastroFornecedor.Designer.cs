﻿namespace testpim
{
    partial class CadastroFornecedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroFornecedor));
            this.panel1 = new System.Windows.Forms.Panel();
            this.atualizaLbl = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ufTbx = new System.Windows.Forms.TextBox();
            this.buscacepBtn = new System.Windows.Forms.Button();
            this.cepMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cidadeTbx = new System.Windows.Forms.TextBox();
            this.enderecoTbx = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.complementoTbx = new System.Windows.Forms.TextBox();
            this.bairroTbx = new System.Windows.Forms.TextBox();
            this.numeroTbx = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.situacaoCbx = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.idfornecTbx = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.siteTbx = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.telfaxMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.emailTbx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nomeFantTbx = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.razaoSocialTbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cnpjMtbx = new System.Windows.Forms.MaskedTextBox();
            this.telcelMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.telempMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ieTbx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.nomeContTbx = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.obsTbx = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(77)))), ((int)(((byte)(67)))));
            this.panel1.Controls.Add(this.atualizaLbl);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Location = new System.Drawing.Point(-2, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1098, 718);
            this.panel1.TabIndex = 11;
            // 
            // atualizaLbl
            // 
            this.atualizaLbl.AutoSize = true;
            this.atualizaLbl.BackColor = System.Drawing.Color.White;
            this.atualizaLbl.Location = new System.Drawing.Point(360, 492);
            this.atualizaLbl.Name = "atualizaLbl";
            this.atualizaLbl.Size = new System.Drawing.Size(0, 13);
            this.atualizaLbl.TabIndex = 51;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.ufTbx);
            this.groupBox4.Controls.Add(this.buscacepBtn);
            this.groupBox4.Controls.Add(this.cepMtbx);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.cidadeTbx);
            this.groupBox4.Controls.Add(this.enderecoTbx);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.complementoTbx);
            this.groupBox4.Controls.Add(this.bairroTbx);
            this.groupBox4.Controls.Add(this.numeroTbx);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(14, 182);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(814, 122);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Logradouro:";
            // 
            // ufTbx
            // 
            this.ufTbx.Location = new System.Drawing.Point(719, 84);
            this.ufTbx.Name = "ufTbx";
            this.ufTbx.Size = new System.Drawing.Size(54, 23);
            this.ufTbx.TabIndex = 16;
            // 
            // buscacepBtn
            // 
            this.buscacepBtn.Location = new System.Drawing.Point(146, 23);
            this.buscacepBtn.Name = "buscacepBtn";
            this.buscacepBtn.Size = new System.Drawing.Size(110, 36);
            this.buscacepBtn.TabIndex = 1;
            this.buscacepBtn.TabStop = false;
            this.buscacepBtn.Text = "Buscar Cep";
            this.buscacepBtn.UseVisualStyleBackColor = true;
            this.buscacepBtn.Click += new System.EventHandler(this.btnLocalizarCep);
            // 
            // cepMtbx
            // 
            this.cepMtbx.Location = new System.Drawing.Point(9, 36);
            this.cepMtbx.Mask = "00000-999";
            this.cepMtbx.Name = "cepMtbx";
            this.cepMtbx.Size = new System.Drawing.Size(116, 23);
            this.cepMtbx.TabIndex = 10;
            this.cepMtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(716, 64);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 17);
            this.label23.TabIndex = 12;
            this.label23.Text = "UF:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(7, 16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 17);
            this.label21.TabIndex = 8;
            this.label21.Text = "CEP:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(279, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Endereço:";
            // 
            // cidadeTbx
            // 
            this.cidadeTbx.Location = new System.Drawing.Point(459, 84);
            this.cidadeTbx.Name = "cidadeTbx";
            this.cidadeTbx.Size = new System.Drawing.Size(254, 23);
            this.cidadeTbx.TabIndex = 15;
            // 
            // enderecoTbx
            // 
            this.enderecoTbx.Location = new System.Drawing.Point(276, 36);
            this.enderecoTbx.Name = "enderecoTbx";
            this.enderecoTbx.Size = new System.Drawing.Size(508, 23);
            this.enderecoTbx.TabIndex = 11;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(456, 64);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 17);
            this.label22.TabIndex = 10;
            this.label22.Text = "Cidade:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 67);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(27, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "N°:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(288, 66);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(108, 17);
            this.label19.TabIndex = 4;
            this.label19.Text = "Complemento:";
            // 
            // complementoTbx
            // 
            this.complementoTbx.Location = new System.Drawing.Point(291, 84);
            this.complementoTbx.Name = "complementoTbx";
            this.complementoTbx.Size = new System.Drawing.Size(162, 23);
            this.complementoTbx.TabIndex = 14;
            // 
            // bairroTbx
            // 
            this.bairroTbx.Location = new System.Drawing.Point(88, 84);
            this.bairroTbx.Name = "bairroTbx";
            this.bairroTbx.Size = new System.Drawing.Size(194, 23);
            this.bairroTbx.TabIndex = 13;
            // 
            // numeroTbx
            // 
            this.numeroTbx.Location = new System.Drawing.Point(9, 84);
            this.numeroTbx.Name = "numeroTbx";
            this.numeroTbx.Size = new System.Drawing.Size(73, 23);
            this.numeroTbx.TabIndex = 12;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(85, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 17);
            this.label20.TabIndex = 6;
            this.label20.Text = "Bairro:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 405);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1076, 262);
            this.dataGridView1.TabIndex = 50;
            this.dataGridView1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.situacaoCbx);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.idfornecTbx);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(834, 182);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(253, 123);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Registro:";
            // 
            // situacaoCbx
            // 
            this.situacaoCbx.AutoCompleteCustomSource.AddRange(new string[] {
            "Ativo",
            "Inativo"});
            this.situacaoCbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.situacaoCbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.situacaoCbx.FormattingEnabled = true;
            this.situacaoCbx.Items.AddRange(new object[] {
            "Ativo",
            "Inativo"});
            this.situacaoCbx.Location = new System.Drawing.Point(83, 89);
            this.situacaoCbx.Name = "situacaoCbx";
            this.situacaoCbx.Size = new System.Drawing.Size(100, 25);
            this.situacaoCbx.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(80, 66);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "Situação:";
            // 
            // idfornecTbx
            // 
            this.idfornecTbx.Enabled = false;
            this.idfornecTbx.Location = new System.Drawing.Point(83, 39);
            this.idfornecTbx.Name = "idfornecTbx";
            this.idfornecTbx.Size = new System.Drawing.Size(100, 23);
            this.idfornecTbx.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(80, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(102, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "ID Fornecedor:";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(776, 669);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(140, 40);
            this.button4.TabIndex = 48;
            this.button4.TabStop = false;
            this.button4.Text = "&Buscar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.btnBuscarFornecedor);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(947, 669);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 40);
            this.button3.TabIndex = 47;
            this.button3.TabStop = false;
            this.button3.Text = "&Editar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnEditarFornecedor);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(174, 669);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 40);
            this.button2.TabIndex = 46;
            this.button2.TabStop = false;
            this.button2.Text = "&Salvar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnClickSalvarFornecedor);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(11, 669);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 40);
            this.button1.TabIndex = 45;
            this.button1.TabStop = false;
            this.button1.Text = "&Novo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnNovofornc);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.siteTbx);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.telfaxMtbx);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.emailTbx);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.nomeFantTbx);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.razaoSocialTbx);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cnpjMtbx);
            this.groupBox2.Controls.Add(this.telcelMtbx);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.telempMtbx);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.ieTbx);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.nomeContTbx);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(14, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1073, 168);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados Pessoais:";
            // 
            // siteTbx
            // 
            this.siteTbx.Location = new System.Drawing.Point(731, 86);
            this.siteTbx.Name = "siteTbx";
            this.siteTbx.Size = new System.Drawing.Size(324, 23);
            this.siteTbx.TabIndex = 6;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(729, 67);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(64, 17);
            this.label15.TabIndex = 29;
            this.label15.Text = "WebSite:";
            // 
            // telfaxMtbx
            // 
            this.telfaxMtbx.Location = new System.Drawing.Point(282, 140);
            this.telfaxMtbx.Mask = "(00) 0000-0000";
            this.telfaxMtbx.Name = "telfaxMtbx";
            this.telfaxMtbx.Size = new System.Drawing.Size(100, 23);
            this.telfaxMtbx.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(279, 120);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 17);
            this.label11.TabIndex = 27;
            this.label11.Text = "Tel. FAX:";
            // 
            // emailTbx
            // 
            this.emailTbx.Location = new System.Drawing.Point(374, 86);
            this.emailTbx.Name = "emailTbx";
            this.emailTbx.Size = new System.Drawing.Size(324, 23);
            this.emailTbx.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(163, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 17);
            this.label4.TabIndex = 25;
            this.label4.Text = "IE:";
            // 
            // nomeFantTbx
            // 
            this.nomeFantTbx.Location = new System.Drawing.Point(732, 38);
            this.nomeFantTbx.Name = "nomeFantTbx";
            this.nomeFantTbx.Size = new System.Drawing.Size(324, 23);
            this.nomeFantTbx.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(729, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 17);
            this.label2.TabIndex = 23;
            this.label2.Text = "Nome Fantasia:";
            // 
            // razaoSocialTbx
            // 
            this.razaoSocialTbx.Location = new System.Drawing.Point(374, 38);
            this.razaoSocialTbx.Name = "razaoSocialTbx";
            this.razaoSocialTbx.Size = new System.Drawing.Size(324, 23);
            this.razaoSocialTbx.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(371, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "Razão Social:";
            // 
            // cnpjMtbx
            // 
            this.cnpjMtbx.Location = new System.Drawing.Point(9, 86);
            this.cnpjMtbx.Mask = "00.000.000/0000-00";
            this.cnpjMtbx.Name = "cnpjMtbx";
            this.cnpjMtbx.Size = new System.Drawing.Size(124, 23);
            this.cnpjMtbx.TabIndex = 3;
            // 
            // telcelMtbx
            // 
            this.telcelMtbx.Location = new System.Drawing.Point(156, 140);
            this.telcelMtbx.Mask = "(00) 00000-0000";
            this.telcelMtbx.Name = "telcelMtbx";
            this.telcelMtbx.Size = new System.Drawing.Size(100, 23);
            this.telcelMtbx.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(153, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 17);
            this.label10.TabIndex = 18;
            this.label10.Text = "Tel. Celular:";
            // 
            // telempMtbx
            // 
            this.telempMtbx.Location = new System.Drawing.Point(10, 140);
            this.telempMtbx.Mask = "(99) 0000-0000";
            this.telempMtbx.Name = "telempMtbx";
            this.telempMtbx.Size = new System.Drawing.Size(120, 23);
            this.telempMtbx.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "Telefone:";
            // 
            // ieTbx
            // 
            this.ieTbx.Location = new System.Drawing.Point(166, 86);
            this.ieTbx.Name = "ieTbx";
            this.ieTbx.Size = new System.Drawing.Size(175, 23);
            this.ieTbx.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "E-mail:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 66);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 17);
            this.label14.TabIndex = 4;
            this.label14.Text = "CNPJ:";
            // 
            // nomeContTbx
            // 
            this.nomeContTbx.Location = new System.Drawing.Point(10, 38);
            this.nomeContTbx.Multiline = true;
            this.nomeContTbx.Name = "nomeContTbx";
            this.nomeContTbx.Size = new System.Drawing.Size(324, 23);
            this.nomeContTbx.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 18);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(112, 17);
            this.label16.TabIndex = 0;
            this.label16.Text = "Nome Contato:";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.obsTbx);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(14, 310);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1073, 89);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Observações:";
            // 
            // obsTbx
            // 
            this.obsTbx.Location = new System.Drawing.Point(9, 22);
            this.obsTbx.Multiline = true;
            this.obsTbx.Name = "obsTbx";
            this.obsTbx.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.obsTbx.Size = new System.Drawing.Size(1059, 61);
            this.obsTbx.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(143, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 24);
            this.label6.TabIndex = 25;
            this.label6.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(736, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 24);
            this.label5.TabIndex = 26;
            this.label5.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Maroon;
            this.label7.Location = new System.Drawing.Point(511, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 24);
            this.label7.TabIndex = 27;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(390, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 24);
            this.label8.TabIndex = 28;
            this.label8.Text = "*";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Maroon;
            this.label24.Location = new System.Drawing.Point(128, 60);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(19, 24);
            this.label24.TabIndex = 29;
            this.label24.Text = "*";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Maroon;
            this.label25.Location = new System.Drawing.Point(27, 59);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 24);
            this.label25.TabIndex = 30;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Maroon;
            this.label26.Location = new System.Drawing.Point(39, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 22);
            this.label26.TabIndex = 31;
            this.label26.Text = "*";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Maroon;
            this.label27.Location = new System.Drawing.Point(346, 11);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 24);
            this.label27.TabIndex = 32;
            this.label27.Text = "*";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Maroon;
            this.label28.Location = new System.Drawing.Point(229, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 24);
            this.label28.TabIndex = 33;
            this.label28.Text = "*";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Maroon;
            this.label29.Location = new System.Drawing.Point(66, 116);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(19, 24);
            this.label29.TabIndex = 34;
            this.label29.Text = "*";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Maroon;
            this.label30.Location = new System.Drawing.Point(417, 62);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 24);
            this.label30.TabIndex = 35;
            this.label30.Text = "*";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Maroon;
            this.label31.Location = new System.Drawing.Point(179, 61);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 24);
            this.label31.TabIndex = 36;
            this.label31.Text = "*";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Maroon;
            this.label32.Location = new System.Drawing.Point(48, 61);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 24);
            this.label32.TabIndex = 37;
            this.label32.Text = "*";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Maroon;
            this.label33.Location = new System.Drawing.Point(113, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(19, 24);
            this.label33.TabIndex = 38;
            this.label33.Text = "*";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Maroon;
            this.label34.Location = new System.Drawing.Point(460, 12);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 24);
            this.label34.TabIndex = 39;
            this.label34.Text = "*";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Maroon;
            this.label35.Location = new System.Drawing.Point(833, 13);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(19, 24);
            this.label35.TabIndex = 40;
            this.label35.Text = "*";
            // 
            // CadastroFornecedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 713);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CadastroFornecedor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Fornecedores";
            this.Load += new System.EventHandler(this.CadastroFornecedor_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox nomeFantTbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox razaoSocialTbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox cnpjMtbx;
        private System.Windows.Forms.MaskedTextBox telcelMtbx;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MaskedTextBox telempMtbx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ieTbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox nomeContTbx;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox obsTbx;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox emailTbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox telfaxMtbx;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox situacaoCbx;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox idfornecTbx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox siteTbx;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox ufTbx;
        private System.Windows.Forms.Button buscacepBtn;
        private System.Windows.Forms.MaskedTextBox cepMtbx;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox cidadeTbx;
        private System.Windows.Forms.TextBox enderecoTbx;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox complementoTbx;
        private System.Windows.Forms.TextBox bairroTbx;
        private System.Windows.Forms.TextBox numeroTbx;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label atualizaLbl;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
    }
}