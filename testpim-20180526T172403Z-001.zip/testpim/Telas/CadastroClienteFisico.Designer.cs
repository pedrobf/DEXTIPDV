﻿namespace testpim
{
    partial class CadastroClienteFisico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroClienteFisico));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pjRdBtn = new System.Windows.Forms.RadioButton();
            this.pfRdBtn = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rgTbx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cnpjMtbx = new System.Windows.Forms.MaskedTextBox();
            this.telcelMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.telresidMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.sexoCbx = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.emailTbx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dataNascMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.cpfMtbx = new System.Windows.Forms.MaskedTextBox();
            this.nomeTbx = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.atualizaLbl = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.ufTbx = new System.Windows.Forms.TextBox();
            this.buscacepBtn = new System.Windows.Forms.Button();
            this.cepMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cidadeTbx = new System.Windows.Forms.TextBox();
            this.enderecoTbx = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.complementoTbx = new System.Windows.Forms.TextBox();
            this.bairroTbx = new System.Windows.Forms.TextBox();
            this.numeroTbx = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.tipoclienteLbl = new System.Windows.Forms.Label();
            this.obsTbx = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.situacaoCbx = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.idclienteTbx = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.pjRdBtn);
            this.groupBox1.Controls.Add(this.pfRdBtn);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(10, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(152, 187);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipo de Cliente:";
            // 
            // pjRdBtn
            // 
            this.pjRdBtn.AutoSize = true;
            this.pjRdBtn.Location = new System.Drawing.Point(10, 109);
            this.pjRdBtn.Name = "pjRdBtn";
            this.pjRdBtn.Size = new System.Drawing.Size(124, 21);
            this.pjRdBtn.TabIndex = 1;
            this.pjRdBtn.Text = "Pessoa Juridica";
            this.pjRdBtn.UseVisualStyleBackColor = true;
            // 
            // pfRdBtn
            // 
            this.pfRdBtn.AutoSize = true;
            this.pfRdBtn.Checked = true;
            this.pfRdBtn.Location = new System.Drawing.Point(10, 64);
            this.pfRdBtn.Name = "pfRdBtn";
            this.pfRdBtn.Size = new System.Drawing.Size(108, 21);
            this.pfRdBtn.TabIndex = 20;
            this.pfRdBtn.TabStop = true;
            this.pfRdBtn.Text = "Pessoa Fisica";
            this.pfRdBtn.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.rgTbx);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cnpjMtbx);
            this.groupBox2.Controls.Add(this.telcelMtbx);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.telresidMtbx);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.sexoCbx);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.emailTbx);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.dataNascMtbx);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.cpfMtbx);
            this.groupBox2.Controls.Add(this.nomeTbx);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(175, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(907, 187);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados Pessoais:";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // rgTbx
            // 
            this.rgTbx.Location = new System.Drawing.Point(801, 40);
            this.rgTbx.Name = "rgTbx";
            this.rgTbx.Size = new System.Drawing.Size(100, 23);
            this.rgTbx.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(798, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "RG:";
            // 
            // cnpjMtbx
            // 
            this.cnpjMtbx.Location = new System.Drawing.Point(674, 40);
            this.cnpjMtbx.Mask = "00.000.000/0000-00";
            this.cnpjMtbx.Name = "cnpjMtbx";
            this.cnpjMtbx.Size = new System.Drawing.Size(124, 23);
            this.cnpjMtbx.TabIndex = 2;
            // 
            // telcelMtbx
            // 
            this.telcelMtbx.Location = new System.Drawing.Point(152, 154);
            this.telcelMtbx.Mask = "(00) 00000-0000";
            this.telcelMtbx.Name = "telcelMtbx";
            this.telcelMtbx.Size = new System.Drawing.Size(100, 23);
            this.telcelMtbx.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(149, 130);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 17);
            this.label10.TabIndex = 18;
            this.label10.Text = "Tel. Celular:";
            // 
            // telresidMtbx
            // 
            this.telresidMtbx.Location = new System.Drawing.Point(10, 154);
            this.telresidMtbx.Mask = "(99) 0000-0000";
            this.telresidMtbx.Name = "telresidMtbx";
            this.telresidMtbx.Size = new System.Drawing.Size(120, 23);
            this.telresidMtbx.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 130);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "Telefone:";
            // 
            // sexoCbx
            // 
            this.sexoCbx.AutoCompleteCustomSource.AddRange(new string[] {
            "Masculino",
            "Feminino"});
            this.sexoCbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.sexoCbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sexoCbx.FormattingEnabled = true;
            this.sexoCbx.Items.AddRange(new object[] {
            "Masculino",
            "Feminino"});
            this.sexoCbx.Location = new System.Drawing.Point(625, 89);
            this.sexoCbx.Name = "sexoCbx";
            this.sexoCbx.Size = new System.Drawing.Size(164, 25);
            this.sexoCbx.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(622, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Sexo:";
            // 
            // emailTbx
            // 
            this.emailTbx.Location = new System.Drawing.Point(10, 88);
            this.emailTbx.Name = "emailTbx";
            this.emailTbx.Size = new System.Drawing.Size(304, 23);
            this.emailTbx.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "E-mail:";
            // 
            // dataNascMtbx
            // 
            this.dataNascMtbx.Location = new System.Drawing.Point(410, 88);
            this.dataNascMtbx.Mask = "00/00/0000";
            this.dataNascMtbx.Name = "dataNascMtbx";
            this.dataNascMtbx.Size = new System.Drawing.Size(100, 23);
            this.dataNascMtbx.TabIndex = 5;
            this.dataNascMtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.dataNascMtbx.ValidatingType = typeof(System.DateTime);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(407, 69);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(148, 17);
            this.label12.TabIndex = 6;
            this.label12.Text = "Data de Nascimento:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(671, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 17);
            this.label14.TabIndex = 4;
            this.label14.Text = "CNPJ:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(555, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 17);
            this.label15.TabIndex = 3;
            this.label15.Text = "CPF:";
            // 
            // cpfMtbx
            // 
            this.cpfMtbx.Location = new System.Drawing.Point(558, 40);
            this.cpfMtbx.Mask = "000.000.000-00";
            this.cpfMtbx.Name = "cpfMtbx";
            this.cpfMtbx.Size = new System.Drawing.Size(101, 23);
            this.cpfMtbx.TabIndex = 1;
            // 
            // nomeTbx
            // 
            this.nomeTbx.Location = new System.Drawing.Point(10, 40);
            this.nomeTbx.Name = "nomeTbx";
            this.nomeTbx.Size = new System.Drawing.Size(533, 23);
            this.nomeTbx.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 24);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 17);
            this.label16.TabIndex = 0;
            this.label16.Text = "Nome/Razão Social:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(77)))), ((int)(((byte)(67)))));
            this.panel1.Controls.Add(this.atualizaLbl);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 722);
            this.panel1.TabIndex = 46;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // atualizaLbl
            // 
            this.atualizaLbl.AutoSize = true;
            this.atualizaLbl.Location = new System.Drawing.Point(410, 515);
            this.atualizaLbl.Name = "atualizaLbl";
            this.atualizaLbl.Size = new System.Drawing.Size(0, 13);
            this.atualizaLbl.TabIndex = 19;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.ufTbx);
            this.groupBox4.Controls.Add(this.buscacepBtn);
            this.groupBox4.Controls.Add(this.cepMtbx);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.cidadeTbx);
            this.groupBox4.Controls.Add(this.enderecoTbx);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.complementoTbx);
            this.groupBox4.Controls.Add(this.bairroTbx);
            this.groupBox4.Controls.Add(this.numeroTbx);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(10, 197);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(814, 127);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Logradouro:";
            // 
            // ufTbx
            // 
            this.ufTbx.Location = new System.Drawing.Point(747, 77);
            this.ufTbx.Name = "ufTbx";
            this.ufTbx.Size = new System.Drawing.Size(61, 23);
            this.ufTbx.TabIndex = 15;
            // 
            // buscacepBtn
            // 
            this.buscacepBtn.Location = new System.Drawing.Point(118, 22);
            this.buscacepBtn.Name = "buscacepBtn";
            this.buscacepBtn.Size = new System.Drawing.Size(129, 36);
            this.buscacepBtn.TabIndex = 1;
            this.buscacepBtn.TabStop = false;
            this.buscacepBtn.Text = "Buscar Cep";
            this.buscacepBtn.UseVisualStyleBackColor = true;
            this.buscacepBtn.Click += new System.EventHandler(this.buscacepBtn_Click);
            // 
            // cepMtbx
            // 
            this.cepMtbx.Location = new System.Drawing.Point(9, 35);
            this.cepMtbx.Mask = "00000-999";
            this.cepMtbx.Name = "cepMtbx";
            this.cepMtbx.Size = new System.Drawing.Size(100, 23);
            this.cepMtbx.TabIndex = 9;
            this.cepMtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(744, 59);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 17);
            this.label23.TabIndex = 12;
            this.label23.Text = "UF:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 14);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 17);
            this.label21.TabIndex = 8;
            this.label21.Text = "CEP:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(266, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Endereço:";
            // 
            // cidadeTbx
            // 
            this.cidadeTbx.Location = new System.Drawing.Point(492, 77);
            this.cidadeTbx.Name = "cidadeTbx";
            this.cidadeTbx.Size = new System.Drawing.Size(232, 23);
            this.cidadeTbx.TabIndex = 14;
            // 
            // enderecoTbx
            // 
            this.enderecoTbx.Location = new System.Drawing.Point(269, 35);
            this.enderecoTbx.Name = "enderecoTbx";
            this.enderecoTbx.Size = new System.Drawing.Size(539, 23);
            this.enderecoTbx.TabIndex = 10;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(489, 59);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 17);
            this.label22.TabIndex = 10;
            this.label22.Text = "Cidade:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 60);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(27, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "N°:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(328, 59);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(108, 17);
            this.label19.TabIndex = 4;
            this.label19.Text = "Complemento:";
            // 
            // complementoTbx
            // 
            this.complementoTbx.Location = new System.Drawing.Point(331, 77);
            this.complementoTbx.Name = "complementoTbx";
            this.complementoTbx.Size = new System.Drawing.Size(136, 23);
            this.complementoTbx.TabIndex = 13;
            // 
            // bairroTbx
            // 
            this.bairroTbx.Location = new System.Drawing.Point(99, 77);
            this.bairroTbx.Name = "bairroTbx";
            this.bairroTbx.Size = new System.Drawing.Size(214, 23);
            this.bairroTbx.TabIndex = 12;
            // 
            // numeroTbx
            // 
            this.numeroTbx.Location = new System.Drawing.Point(9, 77);
            this.numeroTbx.Name = "numeroTbx";
            this.numeroTbx.Size = new System.Drawing.Size(72, 23);
            this.numeroTbx.TabIndex = 11;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(96, 59);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 17);
            this.label20.TabIndex = 6;
            this.label20.Text = "Bairro:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 423);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1073, 237);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.tipoclienteLbl);
            this.groupBox5.Controls.Add(this.obsTbx);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(10, 327);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1073, 89);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Observações:";
            // 
            // tipoclienteLbl
            // 
            this.tipoclienteLbl.AutoSize = true;
            this.tipoclienteLbl.Location = new System.Drawing.Point(188, 54);
            this.tipoclienteLbl.Name = "tipoclienteLbl";
            this.tipoclienteLbl.Size = new System.Drawing.Size(0, 17);
            this.tipoclienteLbl.TabIndex = 18;
            // 
            // obsTbx
            // 
            this.obsTbx.Location = new System.Drawing.Point(9, 22);
            this.obsTbx.Multiline = true;
            this.obsTbx.Name = "obsTbx";
            this.obsTbx.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.obsTbx.Size = new System.Drawing.Size(1059, 61);
            this.obsTbx.TabIndex = 17;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.situacaoCbx);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.idclienteTbx);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(830, 201);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(253, 123);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Registro:";
            // 
            // situacaoCbx
            // 
            this.situacaoCbx.AutoCompleteCustomSource.AddRange(new string[] {
            "Ativo",
            "Inativo"});
            this.situacaoCbx.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.situacaoCbx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.situacaoCbx.FormattingEnabled = true;
            this.situacaoCbx.ItemHeight = 17;
            this.situacaoCbx.Items.AddRange(new object[] {
            "Ativo",
            "Inativo"});
            this.situacaoCbx.Location = new System.Drawing.Point(69, 89);
            this.situacaoCbx.Name = "situacaoCbx";
            this.situacaoCbx.Size = new System.Drawing.Size(100, 25);
            this.situacaoCbx.TabIndex = 4;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(85, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 17);
            this.label13.TabIndex = 2;
            this.label13.Text = "Situação:";
            // 
            // idclienteTbx
            // 
            this.idclienteTbx.Enabled = false;
            this.idclienteTbx.Location = new System.Drawing.Point(69, 39);
            this.idclienteTbx.Name = "idclienteTbx";
            this.idclienteTbx.Size = new System.Drawing.Size(100, 23);
            this.idclienteTbx.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(82, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "ID Cliente:";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(778, 665);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(140, 40);
            this.button7.TabIndex = 45;
            this.button7.TabStop = false;
            this.button7.Text = "&Buscar";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(943, 665);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 40);
            this.button3.TabIndex = 44;
            this.button3.TabStop = false;
            this.button3.Text = "&Editar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(176, 665);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(140, 40);
            this.button6.TabIndex = 43;
            this.button6.TabStop = false;
            this.button6.Text = "&Salvar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.btnSalvar_click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(13, 665);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(140, 40);
            this.button5.TabIndex = 42;
            this.button5.TabStop = false;
            this.button5.Text = "&Novo";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.btnNovoclick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(143, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(549, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(19, 24);
            this.label6.TabIndex = 25;
            this.label6.Text = "*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(657, 64);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(19, 24);
            this.label5.TabIndex = 26;
            this.label5.Text = "*";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Maroon;
            this.label7.Location = new System.Drawing.Point(111, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 24);
            this.label7.TabIndex = 27;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(126, 105);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 24);
            this.label8.TabIndex = 28;
            this.label8.Text = "*";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Maroon;
            this.label24.Location = new System.Drawing.Point(148, 62);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(19, 24);
            this.label24.TabIndex = 29;
            this.label24.Text = "*";
            // 
            // CadastroClienteFisico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1094, 713);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CadastroClienteFisico";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Cliente";
            this.Load += new System.EventHandler(this.CadastroClienteFisico_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton pjRdBtn;
        private System.Windows.Forms.RadioButton pfRdBtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox telcelMtbx;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MaskedTextBox telresidMtbx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox sexoCbx;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox emailTbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox dataNascMtbx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox cpfMtbx;
        private System.Windows.Forms.TextBox nomeTbx;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MaskedTextBox cnpjMtbx;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox rgTbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox situacaoCbx;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox idclienteTbx;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox obsTbx;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox ufTbx;
        private System.Windows.Forms.Button buscacepBtn;
        private System.Windows.Forms.MaskedTextBox cepMtbx;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox cidadeTbx;
        private System.Windows.Forms.TextBox enderecoTbx;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox complementoTbx;
        private System.Windows.Forms.TextBox bairroTbx;
        private System.Windows.Forms.TextBox numeroTbx;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label tipoclienteLbl;
        private System.Windows.Forms.Label atualizaLbl;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label24;
    }
}