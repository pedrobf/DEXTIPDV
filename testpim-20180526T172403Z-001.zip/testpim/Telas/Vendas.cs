﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using testpim.Dao;

namespace testpim.Telas
{
    public class Vendas
    {
        public int Id_Venda { get; set; }
        public Cliente Cliente { get; set; }
        public Produto Produto { get; set; }
        public DateTime Data { get; set; }
        public int Qtd { get; set; }
        public String Tamanho { get; set; }
        public Estoque Estoque { get; set; }
        public int Codigo { get; set; }
        public MySqlConnection Con { get; set; }
        public MySqlCommand AdVenda { get; set; }
        public MySqlCommand Deletar { get; set; }
        

        public Vendas()
        {

            Produto = new Produto();
            Con = new ConnectionFactory().Connectar();
            Cliente = new Cliente();
        }

        public String BuscarCliente(TextBox nome)
        {

            Con.Open();
            string buscar_cliente = "Select id_client from cliente where nome = '" + nome.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_cliente, Con);
            string id = cmd.ExecuteScalar().ToString();
            Con.Close();
            return id;
        }
        public DataTable VerificarCadatsroCliente(TextBox nome)
        {

            Con.Open();
            string buscar_cliente = "Select id_client from cliente where nome = '" + nome.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_cliente, Con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;
        }

        public DataTable BuscarProduto(TextBox nome)
        {

            Con.Open();
            string buscar_produto = "Select id_produto,nome,descricao,tipo,genero,preco_venda from demo  where nome= '" + nome.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_produto, Con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;
        }

        public int BuscarEstoque(TextBox tamanho, TextBox id)
        {
            MySqlConnection Con = new ConnectionFactory().Connectar();
            Con.Open();
            string buscar_qtd = "Select qtd from estoque where tamanho='" + tamanho.Text + "' AND id_produto='" + id.Text + "'";
            MySqlCommand cmd = new MySqlCommand(buscar_qtd, Con);
            int qtd = Convert.ToInt32(cmd.ExecuteScalar().ToString());
            return qtd;


        }

        public bool IncluirProduto(Vendas vendas)
        {
            int verifica;

            try
            {

                string inserir = "INSERT INTO venda (id_cliente,codigo,nome_cliente,id_produto,nome_produto,genero_produto,tipo_produto,data_venda,qtd,valor) VALUES(@id_cliente,@codigo,@nome_cliente,@id_produto,@nome_produto,@genero_produto,@tipo_produto,@data_venda,@qtd,@valor);";
                AdVenda = new MySqlCommand(inserir, Con);
                Con.Open();
                AdVenda.Parameters.Add(new MySqlParameter("id_cliente", vendas.Cliente.Id));
                AdVenda.Parameters.Add(new MySqlParameter("codigo", vendas.Codigo));
                AdVenda.Parameters.Add(new MySqlParameter("nome_cliente", vendas.Cliente.Nome));
                AdVenda.Parameters.Add(new MySqlParameter("id_produto", vendas.Produto.IdProduto));
                AdVenda.Parameters.Add(new MySqlParameter("nome_produto", vendas.Produto.Nome));
                AdVenda.Parameters.Add(new MySqlParameter("genero_produto", vendas.Produto.Genero));
                AdVenda.Parameters.Add(new MySqlParameter("tipo_produto", vendas.Produto.Tipo));
                AdVenda.Parameters.Add(new MySqlParameter("data_venda", vendas.Data));
                AdVenda.Parameters.Add(new MySqlParameter("qtd", vendas.Qtd));
                AdVenda.Parameters.Add(new MySqlParameter("valor", vendas.Produto.PrecoVenda));
                AdVenda.Prepare();
                AdVenda.ExecuteNonQuery();
                Con.Close();
                verifica = 1;

            }
            catch (Exception erro)
            {
                verifica = 0;
                throw erro;
            }
            return verifica > 0;


        }

        public DataTable ListarVendas()
        {
            string listar = "Select id_venda,id_cliente,codigo,nome_cliente,id_produto,nome_produto,genero_produto,tipo_produto,data_venda,qtd,valor from venda";
            MySqlCommand cmd = new MySqlCommand(listar, Con);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;
        }

        public int getId(Vendas vendas)
        {
            Con.Open();
            string pegarid = "Select id_venda from venda where nome_produto='" + vendas.Produto.Nome + "'";
            MySqlCommand cmd = new MySqlCommand(pegarid, Con);
            cmd.Prepare();
            Id_Venda = int.Parse(cmd.ExecuteScalar().ToString());
            Con.Close();
            return Id_Venda;

        }

        public bool DeletarDados(Vendas venda)
        {
            int verifica;
            try
            {
                string deletar = "DELETE FROM venda WHERE id_venda=@id_venda";
                Deletar = new MySqlCommand(deletar, Con);
                Con.Open();
                Deletar.Parameters.Add(new MySqlParameter("id_venda", venda.Id_Venda));
                Deletar.Prepare();
                Deletar.ExecuteNonQuery();
                Con.Close();
                verifica = 1;

            }
            catch (Exception erro)
            {
                verifica = 0;
                throw erro;
            }
            return verifica > 0;
        }

         public void DarBaixaEstoque( int quantidade, int idProduto)
        {
           
            try
            {
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = Con;
                Con.Open();
                cmd.CommandText = "UPDATE estoque SET qtd= qtd - @quantidade where id_produto=@idProduto;";
                cmd.Parameters.AddWithValue("@idProduto", idProduto);
                cmd.Parameters.AddWithValue("@quantidade", quantidade);
                cmd.Prepare();
                cmd.ExecuteNonQuery();
                Con.Close();
             
            }catch(Exception erro)
            {
               
                throw erro;
            }
        

        }

        public string ValorVenda(int codigo,DateTime data)
        {
            Con.Open();
            string pegarid = "Select SUM(qtd*valor) from venda where codigo=@codigo and data_venda=@data";
            MySqlCommand cmd = new MySqlCommand(pegarid, Con);
            cmd.Parameters.AddWithValue("@codigo",codigo);
            cmd.Parameters.AddWithValue("@data", data);
            cmd.Prepare();
            cmd.ExecuteNonQuery();
            string total =cmd.ExecuteScalar().ToString();
            Con.Close();
            return total;
        }

        public DataTable RelatorioClientePeriodo(DateTime data_inicial,DateTime data_final,string nome_cliente)
        {
            string relatorio = "SELECT  id_venda,id_cliente,nome_cliente,id_produto,nome_produto,genero_produto,tipo_produto,data_venda,qtd,valor from venda WHERE data_venda BETWEEN @data_inicial AND @data_final AND nome_cliente=@cliente";
            AdVenda = new MySqlCommand(relatorio, Con);
            AdVenda.Parameters.AddWithValue("@data_inicial", data_inicial);
            AdVenda.Parameters.AddWithValue("@data_final", data_final);
            AdVenda.Parameters.AddWithValue("@cliente", nome_cliente);
            MySqlDataAdapter adp = new MySqlDataAdapter(AdVenda);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;

        }

        public DataTable RelatorioPeriodo(DateTime data_inicial, DateTime data_final)
        {
            string relatorio = "SELECT  id_venda,id_cliente,nome_cliente,id_produto,nome_produto,genero_produto,tipo_produto,data_venda,qtd,valor from venda WHERE data_venda BETWEEN @data_inicial AND @data_final";
            AdVenda = new MySqlCommand(relatorio, Con);
            AdVenda.Parameters.AddWithValue("@data_inicial", data_inicial);
            AdVenda.Parameters.AddWithValue("@data_final", data_final);
            MySqlDataAdapter adp = new MySqlDataAdapter(AdVenda);
            DataTable tb = new DataTable();
            adp.Fill(tb);
            Con.Close();
            return tb;

        }

       

    }
}
