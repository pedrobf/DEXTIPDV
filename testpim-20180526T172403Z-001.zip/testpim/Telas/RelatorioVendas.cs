﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using testpim.Telas;

namespace testpim
{
    public partial class RelatorioVendas : Form
    {
        Formulario form;
        Vendas venda;
        public RelatorioVendas()
        {
            InitializeComponent();
            venda = new Vendas();
            form = new Formulario();
        }
       public void  LimparDados()
        {
            form.LimpaTextBoxs(clienteTbx);
            form.LimpaMaskedTextBoxs(data_finalMtbx);
            form.LimpaMaskedTextBoxs(data_inicialMtbx);
           
            
        }
        private void button4_Click(object sender, EventArgs e)
        {
            form.RetiraMascaras(data_finalMtbx);
            form.RetiraMascaras(data_inicialMtbx);
            if ((data_inicialMtbx.Text == "") || (data_finalMtbx.Text == ""))
            {
                MessageBox.Show("Campos obrigatórios vazios, preencha todos os campos que contém * !!!");
            }
            else
            {
              
                if ((clienteTbx.Text != "") && (data_inicialMtbx.Text!="")&&(data_finalMtbx.Text!=""))
                {

                    form.IncluirMascaras(data_finalMtbx);
                    form.IncluirMascaras(data_inicialMtbx);
                    DataTable tb = venda.RelatorioClientePeriodo(DateTime.Parse(data_inicialMtbx.Text), DateTime.Parse(data_finalMtbx.Text), clienteTbx.Text);
                    if (tb.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = venda.RelatorioClientePeriodo(DateTime.Parse(data_inicialMtbx.Text), DateTime.Parse(data_finalMtbx.Text), clienteTbx.Text);
                    }
                    else
                    {
                        MessageBox.Show("Nenhuma Venda Encontrada para este período para este CLIENTE!!");
                    }
                } else {

                    form.IncluirMascaras(data_finalMtbx);
                    form.IncluirMascaras(data_inicialMtbx);
                    DataTable tb = venda.RelatorioPeriodo(DateTime.Parse(data_inicialMtbx.Text), DateTime.Parse(data_finalMtbx.Text));
                    if (tb.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = tb;
                    }
                    else
                    {
                        MessageBox.Show("Nenhuma Venda Encontrada para este período!!");
                    }

                } 
               
            }
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LimparDados();
        }
    }
}
