﻿namespace testpim
{
    partial class CadastroFuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroFuncionario));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.celularMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.telresidencialMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.estadocivilCbo = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.sexoCbo = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.emailTbs = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tituloeleitorTbx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.datanascimentoMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rgMtbx = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cpfMtbx = new System.Windows.Forms.MaskedTextBox();
            this.nomeTbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.idTbx = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.datademissaoMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comissaoTbx = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.salarioTbx = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ctpsTbx = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dataadmissaoTbx = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.funcaoTbx = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.ufTbx = new System.Windows.Forms.TextBox();
            this.buscacepBtn = new System.Windows.Forms.Button();
            this.cepMtbx = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.cidadeTbx = new System.Windows.Forms.TextBox();
            this.enderecoTbx = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.complementoTbx = new System.Windows.Forms.TextBox();
            this.bairroTbx = new System.Windows.Forms.TextBox();
            this.numeroTbx = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.obsTbx = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.atualizarLbl = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(6, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(81, 128);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Foto";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 103);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.celularMtbx);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.telresidencialMtbx);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.estadocivilCbo);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.sexoCbo);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.emailTbs);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tituloeleitorTbx);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.datanascimentoMtbx);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.rgMtbx);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cpfMtbx);
            this.groupBox2.Controls.Add(this.nomeTbx);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(91, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(996, 129);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dados Pessoais:";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Maroon;
            this.label34.Location = new System.Drawing.Point(701, 70);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 24);
            this.label34.TabIndex = 34;
            this.label34.Text = "*";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Maroon;
            this.label33.Location = new System.Drawing.Point(923, 72);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(19, 24);
            this.label33.TabIndex = 33;
            this.label33.Text = "*";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Maroon;
            this.label32.Location = new System.Drawing.Point(758, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(19, 24);
            this.label32.TabIndex = 32;
            this.label32.Text = "*";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Maroon;
            this.label31.Location = new System.Drawing.Point(423, 72);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(19, 24);
            this.label31.TabIndex = 31;
            this.label31.Text = "*";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Maroon;
            this.label30.Location = new System.Drawing.Point(539, 72);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(19, 24);
            this.label30.TabIndex = 30;
            this.label30.Text = "*";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Maroon;
            this.label29.Location = new System.Drawing.Point(52, 72);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(19, 24);
            this.label29.TabIndex = 29;
            this.label29.Text = "*";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Maroon;
            this.label28.Location = new System.Drawing.Point(944, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(19, 24);
            this.label28.TabIndex = 28;
            this.label28.Text = "*";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Maroon;
            this.label27.Location = new System.Drawing.Point(748, 16);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(19, 24);
            this.label27.TabIndex = 27;
            this.label27.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Maroon;
            this.label26.Location = new System.Drawing.Point(611, 16);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(19, 24);
            this.label26.TabIndex = 26;
            this.label26.Text = "*";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Maroon;
            this.label25.Location = new System.Drawing.Point(52, 16);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(19, 24);
            this.label25.TabIndex = 25;
            this.label25.Text = "*";
            // 
            // celularMtbx
            // 
            this.celularMtbx.Location = new System.Drawing.Point(467, 96);
            this.celularMtbx.Mask = "(00) 00000-0000";
            this.celularMtbx.Name = "celularMtbx";
            this.celularMtbx.Size = new System.Drawing.Size(100, 23);
            this.celularMtbx.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(463, 77);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 17);
            this.label10.TabIndex = 18;
            this.label10.Text = "Tel. Celular:";
            // 
            // telresidencialMtbx
            // 
            this.telresidencialMtbx.Location = new System.Drawing.Point(324, 96);
            this.telresidencialMtbx.Mask = "(99) 0000-0000";
            this.telresidencialMtbx.Name = "telresidencialMtbx";
            this.telresidencialMtbx.Size = new System.Drawing.Size(120, 23);
            this.telresidencialMtbx.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(321, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "Tel. Residencial:";
            // 
            // estadocivilCbo
            // 
            this.estadocivilCbo.AutoCompleteCustomSource.AddRange(new string[] {
            "Solteiro(a)",
            "Casado(a)",
            "Separado(a)",
            "Divorciado(a)",
            "Viúvo(a)"});
            this.estadocivilCbo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.estadocivilCbo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.estadocivilCbo.FormattingEnabled = true;
            this.estadocivilCbo.Items.AddRange(new object[] {
            "Solteiro(a)",
            "Casado(a)",
            "Separado(a)",
            "Divorciado(a)",
            "Viúvo(a)"});
            this.estadocivilCbo.Location = new System.Drawing.Point(845, 96);
            this.estadocivilCbo.Name = "estadocivilCbo";
            this.estadocivilCbo.Size = new System.Drawing.Size(131, 25);
            this.estadocivilCbo.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(841, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Estado Civil:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // sexoCbo
            // 
            this.sexoCbo.AutoCompleteCustomSource.AddRange(new string[] {
            "Masculino",
            "Feminino"});
            this.sexoCbo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.sexoCbo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sexoCbo.FormattingEnabled = true;
            this.sexoCbo.Items.AddRange(new object[] {
            "Masculino",
            "Feminino"});
            this.sexoCbo.Location = new System.Drawing.Point(726, 94);
            this.sexoCbo.Name = "sexoCbo";
            this.sexoCbo.Size = new System.Drawing.Size(100, 25);
            this.sexoCbo.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(723, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Sexo:";
            // 
            // emailTbs
            // 
            this.emailTbs.Location = new System.Drawing.Point(10, 96);
            this.emailTbs.Name = "emailTbs";
            this.emailTbs.Size = new System.Drawing.Size(304, 23);
            this.emailTbs.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "E-mail:";
            // 
            // tituloeleitorTbx
            // 
            this.tituloeleitorTbx.Location = new System.Drawing.Point(843, 40);
            this.tituloeleitorTbx.Name = "tituloeleitorTbx";
            this.tituloeleitorTbx.Size = new System.Drawing.Size(131, 23);
            this.tituloeleitorTbx.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(841, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Titulo de Eleitor:";
            // 
            // datanascimentoMtbx
            // 
            this.datanascimentoMtbx.Location = new System.Drawing.Point(583, 96);
            this.datanascimentoMtbx.Mask = "00/00/0000";
            this.datanascimentoMtbx.Name = "datanascimentoMtbx";
            this.datanascimentoMtbx.Size = new System.Drawing.Size(100, 23);
            this.datanascimentoMtbx.TabIndex = 7;
            this.datanascimentoMtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.datanascimentoMtbx.ValidatingType = typeof(System.DateTime);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(559, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Data de Nascimento:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // rgMtbx
            // 
            this.rgMtbx.Location = new System.Drawing.Point(726, 40);
            this.rgMtbx.Name = "rgMtbx";
            this.rgMtbx.Size = new System.Drawing.Size(100, 23);
            this.rgMtbx.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(723, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "RG:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(580, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "CPF:";
            // 
            // cpfMtbx
            // 
            this.cpfMtbx.Location = new System.Drawing.Point(583, 40);
            this.cpfMtbx.Mask = "000.000.000-00";
            this.cpfMtbx.Name = "cpfMtbx";
            this.cpfMtbx.Size = new System.Drawing.Size(100, 23);
            this.cpfMtbx.TabIndex = 1;
            // 
            // nomeTbx
            // 
            this.nomeTbx.Location = new System.Drawing.Point(10, 40);
            this.nomeTbx.Name = "nomeTbx";
            this.nomeTbx.Size = new System.Drawing.Size(533, 23);
            this.nomeTbx.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome: ";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.idTbx);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.datademissaoMtbx);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.comissaoTbx);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.salarioTbx);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.ctpsTbx);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.dataadmissaoTbx);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.funcaoTbx);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(5, 147);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(405, 127);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dados Funcionario:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Maroon;
            this.label39.Location = new System.Drawing.Point(58, 65);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(19, 24);
            this.label39.TabIndex = 39;
            this.label39.Text = "*";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Maroon;
            this.label38.Location = new System.Drawing.Point(300, 15);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(19, 24);
            this.label38.TabIndex = 38;
            this.label38.Text = "*";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Maroon;
            this.label37.Location = new System.Drawing.Point(358, 15);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(19, 24);
            this.label37.TabIndex = 37;
            this.label37.Text = "*";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Maroon;
            this.label36.Location = new System.Drawing.Point(121, 15);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(19, 24);
            this.label36.TabIndex = 36;
            this.label36.Text = "*";
            // 
            // idTbx
            // 
            this.idTbx.Enabled = false;
            this.idTbx.Location = new System.Drawing.Point(12, 39);
            this.idTbx.Name = "idTbx";
            this.idTbx.Size = new System.Drawing.Size(52, 23);
            this.idTbx.TabIndex = 13;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 23);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(25, 17);
            this.label24.TabIndex = 12;
            this.label24.Text = "ID:";
            // 
            // datademissaoMtbx
            // 
            this.datademissaoMtbx.Location = new System.Drawing.Point(274, 89);
            this.datademissaoMtbx.Mask = "00/00/0000";
            this.datademissaoMtbx.Name = "datademissaoMtbx";
            this.datademissaoMtbx.Size = new System.Drawing.Size(100, 23);
            this.datademissaoMtbx.TabIndex = 15;
            this.datademissaoMtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.datademissaoMtbx.ValidatingType = typeof(System.DateTime);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(249, 71);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(132, 17);
            this.label16.TabIndex = 10;
            this.label16.Text = "Data de Demissão:";
            // 
            // comissaoTbx
            // 
            this.comissaoTbx.Location = new System.Drawing.Point(143, 89);
            this.comissaoTbx.Name = "comissaoTbx";
            this.comissaoTbx.Size = new System.Drawing.Size(100, 23);
            this.comissaoTbx.TabIndex = 14;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(140, 73);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(90, 17);
            this.label15.TabIndex = 8;
            this.label15.Text = "Comissão %:";
            // 
            // salarioTbx
            // 
            this.salarioTbx.Location = new System.Drawing.Point(12, 89);
            this.salarioTbx.Name = "salarioTbx";
            this.salarioTbx.Size = new System.Drawing.Size(100, 23);
            this.salarioTbx.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 73);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 17);
            this.label14.TabIndex = 6;
            this.label14.Text = "Salário:";
            // 
            // ctpsTbx
            // 
            this.ctpsTbx.Location = new System.Drawing.Point(299, 39);
            this.ctpsTbx.Name = "ctpsTbx";
            this.ctpsTbx.Size = new System.Drawing.Size(100, 23);
            this.ctpsTbx.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(322, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 17);
            this.label13.TabIndex = 4;
            this.label13.Text = "CTPS:";
            // 
            // dataadmissaoTbx
            // 
            this.dataadmissaoTbx.Location = new System.Drawing.Point(176, 39);
            this.dataadmissaoTbx.Mask = "00/00/0000";
            this.dataadmissaoTbx.Name = "dataadmissaoTbx";
            this.dataadmissaoTbx.Size = new System.Drawing.Size(100, 23);
            this.dataadmissaoTbx.TabIndex = 11;
            this.dataadmissaoTbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.dataadmissaoTbx.ValidatingType = typeof(System.DateTime);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(173, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Data de Admissão:";
            // 
            // funcaoTbx
            // 
            this.funcaoTbx.Location = new System.Drawing.Point(70, 39);
            this.funcaoTbx.Name = "funcaoTbx";
            this.funcaoTbx.Size = new System.Drawing.Size(100, 23);
            this.funcaoTbx.TabIndex = 10;
            this.funcaoTbx.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(67, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "Função:";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.label48);
            this.groupBox4.Controls.Add(this.label47);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.ufTbx);
            this.groupBox4.Controls.Add(this.buscacepBtn);
            this.groupBox4.Controls.Add(this.cepMtbx);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.cidadeTbx);
            this.groupBox4.Controls.Add(this.enderecoTbx);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.complementoTbx);
            this.groupBox4.Controls.Add(this.bairroTbx);
            this.groupBox4.Controls.Add(this.numeroTbx);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(414, 147);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(673, 127);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Logradouro:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Maroon;
            this.label48.Location = new System.Drawing.Point(631, 65);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(19, 24);
            this.label48.TabIndex = 48;
            this.label48.Text = "*";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Maroon;
            this.label47.Location = new System.Drawing.Point(472, 65);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(19, 24);
            this.label47.TabIndex = 47;
            this.label47.Text = "*";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.Maroon;
            this.label46.Location = new System.Drawing.Point(374, 65);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(19, 24);
            this.label46.TabIndex = 46;
            this.label46.Text = "*";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Maroon;
            this.label45.Location = new System.Drawing.Point(115, 65);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(19, 24);
            this.label45.TabIndex = 45;
            this.label45.Text = "*";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Maroon;
            this.label44.Location = new System.Drawing.Point(27, 65);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(19, 24);
            this.label44.TabIndex = 44;
            this.label44.Text = "*";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Maroon;
            this.label43.Location = new System.Drawing.Point(282, 15);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(19, 24);
            this.label43.TabIndex = 43;
            this.label43.Text = "*";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Maroon;
            this.label42.Location = new System.Drawing.Point(34, 15);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(19, 24);
            this.label42.TabIndex = 42;
            this.label42.Text = "*";
            // 
            // ufTbx
            // 
            this.ufTbx.Location = new System.Drawing.Point(611, 89);
            this.ufTbx.Name = "ufTbx";
            this.ufTbx.Size = new System.Drawing.Size(54, 23);
            this.ufTbx.TabIndex = 22;
            // 
            // buscacepBtn
            // 
            this.buscacepBtn.Location = new System.Drawing.Point(109, 26);
            this.buscacepBtn.Name = "buscacepBtn";
            this.buscacepBtn.Size = new System.Drawing.Size(100, 36);
            this.buscacepBtn.TabIndex = 1;
            this.buscacepBtn.TabStop = false;
            this.buscacepBtn.Text = "Buscar Cep";
            this.buscacepBtn.UseVisualStyleBackColor = true;
            this.buscacepBtn.Click += new System.EventHandler(this.buscacepBtn_Click);
            // 
            // cepMtbx
            // 
            this.cepMtbx.Location = new System.Drawing.Point(6, 39);
            this.cepMtbx.Mask = "00000-999";
            this.cepMtbx.Name = "cepMtbx";
            this.cepMtbx.Size = new System.Drawing.Size(100, 23);
            this.cepMtbx.TabIndex = 16;
            this.cepMtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.cepMtbx.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox7_MaskInputRejected);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(611, 73);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 17);
            this.label23.TabIndex = 12;
            this.label23.Text = "UF:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(2, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(38, 17);
            this.label21.TabIndex = 8;
            this.label21.Text = "CEP:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(215, 22);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 17);
            this.label17.TabIndex = 0;
            this.label17.Text = "Endereço:";
            // 
            // cidadeTbx
            // 
            this.cidadeTbx.Location = new System.Drawing.Point(417, 89);
            this.cidadeTbx.Name = "cidadeTbx";
            this.cidadeTbx.Size = new System.Drawing.Size(188, 23);
            this.cidadeTbx.TabIndex = 21;
            // 
            // enderecoTbx
            // 
            this.enderecoTbx.Location = new System.Drawing.Point(215, 39);
            this.enderecoTbx.Name = "enderecoTbx";
            this.enderecoTbx.Size = new System.Drawing.Size(436, 23);
            this.enderecoTbx.TabIndex = 17;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(417, 73);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(61, 17);
            this.label22.TabIndex = 10;
            this.label22.Text = "Cidade:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 71);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(27, 17);
            this.label18.TabIndex = 2;
            this.label18.Text = "N°:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(272, 72);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(108, 17);
            this.label19.TabIndex = 4;
            this.label19.Text = "Complemento:";
            // 
            // complementoTbx
            // 
            this.complementoTbx.Location = new System.Drawing.Point(275, 89);
            this.complementoTbx.Name = "complementoTbx";
            this.complementoTbx.Size = new System.Drawing.Size(136, 23);
            this.complementoTbx.TabIndex = 20;
            // 
            // bairroTbx
            // 
            this.bairroTbx.Location = new System.Drawing.Point(75, 89);
            this.bairroTbx.Name = "bairroTbx";
            this.bairroTbx.Size = new System.Drawing.Size(194, 23);
            this.bairroTbx.TabIndex = 19;
            // 
            // numeroTbx
            // 
            this.numeroTbx.Location = new System.Drawing.Point(6, 89);
            this.numeroTbx.Name = "numeroTbx";
            this.numeroTbx.Size = new System.Drawing.Size(60, 23);
            this.numeroTbx.TabIndex = 18;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(73, 73);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 17);
            this.label20.TabIndex = 6;
            this.label20.Text = "Bairro:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 377);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1082, 285);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(183)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.obsTbx);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(5, 280);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1082, 89);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Observações:";
            // 
            // obsTbx
            // 
            this.obsTbx.Location = new System.Drawing.Point(9, 22);
            this.obsTbx.Multiline = true;
            this.obsTbx.Name = "obsTbx";
            this.obsTbx.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.obsTbx.Size = new System.Drawing.Size(1066, 61);
            this.obsTbx.TabIndex = 23;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(77)))), ((int)(((byte)(67)))));
            this.panel1.Controls.Add(this.atualizarLbl);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(-3, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1098, 718);
            this.panel1.TabIndex = 10;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // atualizarLbl
            // 
            this.atualizarLbl.AutoSize = true;
            this.atualizarLbl.Location = new System.Drawing.Point(119, 454);
            this.atualizarLbl.Name = "atualizarLbl";
            this.atualizarLbl.Size = new System.Drawing.Size(0, 13);
            this.atualizarLbl.TabIndex = 8;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(774, 666);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(140, 40);
            this.button4.TabIndex = 8;
            this.button4.TabStop = false;
            this.button4.Text = "&Buscar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(945, 666);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 40);
            this.button3.TabIndex = 6;
            this.button3.TabStop = false;
            this.button3.Text = "&Editar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(172, 666);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 40);
            this.button2.TabIndex = 5;
            this.button2.TabStop = false;
            this.button2.Text = "&Salvar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(9, 666);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 40);
            this.button1.TabIndex = 4;
            this.button1.TabStop = false;
            this.button1.Text = "&Novo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // CadastroFuncionario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1094, 713);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CadastroFuncionario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Funcionario";
            this.Load += new System.EventHandler(this.CadastroFuncionario_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox rgMtbx;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox cpfMtbx;
        private System.Windows.Forms.TextBox nomeTbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tituloeleitorTbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox datanascimentoMtbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox emailTbs;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox estadocivilCbo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox sexoCbo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.MaskedTextBox telresidencialMtbx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox funcaoTbx;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox dataadmissaoTbx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox salarioTbx;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox ctpsTbx;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox comissaoTbx;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox datademissaoMtbx;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox complementoTbx;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox numeroTbx;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox enderecoTbx;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox cidadeTbx;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.MaskedTextBox cepMtbx;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox bairroTbx;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox idTbx;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.MaskedTextBox celularMtbx;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox obsTbx;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buscacepBtn;
        private System.Windows.Forms.Label atualizarLbl;
        private System.Windows.Forms.TextBox ufTbx;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
    }
}