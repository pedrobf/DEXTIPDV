﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testpim.Dao
{
    public class ConnectionFactory
    {
        private string Conexao = "server=localhost;user id=root;password=aquela123;database=pimads3;SslMode=none";
        public MySqlConnection Connectar()
        {
            return new MySqlConnection(Conexao);
        }
    }
}
