﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testpim
{
    public class Validacao
    {
        public bool ValidarCpf(string Cpf)
        {
            if (Cpf == "")
            {
                return false;
            }
            else
            {
                int[] Dig1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
                int[] Dig2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
                string ArmazenaCpf = "";
                string Digito;
                int soma, resto, x;
                if (Cpf.Length != 11)
                {
                    Cpf = Cpf.Trim();//Tira espaços em branco
                    Cpf = Cpf.Replace(",", "").Replace("-", "");//Coloca espaços vazios onde era vírgula e traço

                }
                ArmazenaCpf = Cpf.Substring(0, 9);//Recebe os 9 primeiros digitos do CPF
                if ((Cpf != "00000000000") && (Cpf != "11111111111") && (Cpf != "22222222222") && (Cpf != "33333333333") && (Cpf != "44444444444") && (Cpf != "55555555555") && (Cpf != "66666666666") && (Cpf != "77777777777") && (Cpf != "88888888888") && (Cpf != "99999999999"))//Verifica se os 11 dígitos correspondem a valores que não sejam todos eles iguais
                {
                    //Digito1
                    soma = 0;
                    for (x = 0; x < 9; x++)
                    {
                        soma += int.Parse(ArmazenaCpf[x].ToString()) * Dig1[x];//Faz a multiplicação dos dígitos por suas respectivas posições
                    }
                    resto = soma % 11;//verifica resto da divisão
                    if (resto < 2)
                    {
                        resto = 0;
                    }
                    else
                    {
                        resto = 11 - resto;
                    }
                    Digito = resto.ToString();
                    ArmazenaCpf = ArmazenaCpf + Digito;
                    //Digito 2
                    soma = 0;
                    for (x = 0; x < 10; x++)
                    {
                        soma += int.Parse(ArmazenaCpf[x].ToString()) * Dig2[x];//Faz a multiplicação dos dígitos por suas respectivas posições
                    }
                    resto = soma % 11;// verifica resto da divisão por 11
                    if (resto < 2)
                    {
                        resto = 0;
                    }
                    else
                    {
                        resto = 11 - resto;
                    }
                    Digito = resto.ToString();
                    ArmazenaCpf = ArmazenaCpf + Digito;
                    return Cpf.EndsWith(Digito);//retorna valor de Cpf válido
                }
                else
                {
                    return false;//retorna falaso para CPf não válido
                }
            }
        }

        public bool ValidarEmail(string Email)
        {
            if (Email == "")
            {
                return false;
            } else  {
                bool verificar = Email.Contains("@") && (Email.Contains(".com"));
                return verificar;
            }
          
           
        }
        ///----------------------------------------------
        public bool ValidarRG(string RG)
        {
            try
            {
                // Pegar os 8 primeiros dígitos e multiplicar o primeiro por 2, e cada número subir + 1 até chegar em 9
                RG = RG.Replace(".", "").Replace("-", "").Replace(",", "").Replace(" ", "").Trim();
                int n1 = int.Parse(RG.Substring(0, 1));
                int n2 = int.Parse(RG.Substring(1, 1));
                int n3 = int.Parse(RG.Substring(2, 1));
                int n4 = int.Parse(RG.Substring(3, 1));
                int n5 = int.Parse(RG.Substring(4, 1));
                int n6 = int.Parse(RG.Substring(5, 1));
                int n7 = int.Parse(RG.Substring(6, 1));
                int n8 = int.Parse(RG.Substring(7, 1));
                string DV = RG.Substring(8, 1);
                int Soma = n1 * 2 + n2 * 3 + n3 * 4 + n4 * 5 + n5 * 6 + n6 * 7 + n7 * 8 + n8 * 9;
                string digitoVerificador = Convert.ToString(Soma % 11);
                // Se o dígito verificador for igual a 1, automaticamente ele se tornará o algarismo romano X,
                // pois será feito o cálculo de 11 - o dígito verificador. No caso, ficaria 11 - 1, que é igual a 10.

                if (digitoVerificador == "1")
                {
                    digitoVerificador = "X";
                }
                // Se o dígito verificador for igual a 0, automaticamente ele se torna 0, pois 11 - 0 é igual a 11, e
                // não será permitido isso no dígito verificador, então automaticamente o dígito será 0.
                else if (digitoVerificador == "0")
                {
                    digitoVerificador = "0";
                }

                // Se não for nem 0 nem 1, vai ser feito 11 - o dígito verificador. Por exemplo, se o a soma dividida por 11
                // deu resto 5, será feito 11 - 5, que é igual a 6. Então automaticamente o dígito verificador do RG se tornará o número 6!

                else
                {
                    digitoVerificador = (11 - int.Parse(digitoVerificador)).ToString();
                }

                // Verificar se o dígito verificador é igual ao DV do RG que está sendo validado.

                if (digitoVerificador == DV)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
        public bool ValidaCnpj(string cnpj)

        {

            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            int soma;

            int resto;

            string digito;

            string tempCnpj;

            cnpj = cnpj.Trim();

            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");

            if (cnpj.Length != 14)

                return false;

            tempCnpj = cnpj.Substring(0, 12);

            soma = 0;

            for (int i = 0; i < 12; i++)

                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];

            resto = (soma % 11);

            if (resto < 2)

                resto = 0;

            else

                resto = 11 - resto;

            digito = resto.ToString();

            tempCnpj = tempCnpj + digito;

            soma = 0;

            for (int i = 0; i < 13; i++)

                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];

            resto = (soma % 11);

            if (resto < 2)

                resto = 0;

            else

                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cnpj.EndsWith(digito);

        }

    }
}

